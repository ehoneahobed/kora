# Kora.js Codebase Mind Map Outline

## 1. Kora.js Ecosystem Overview
    1.1. Core Philosophy
        1.1.1. Offline-First
        1.1.2. Eventual Consistency
        1.1.3. Causal Ordering
        1.1.4. Deterministic Conflict Resolution
        1.1.5. Local-First / Optimistic UI
        1.1.6. TypeScript-First
    1.2. Monorepo Structure (pnpm, Turbo)
        1.2.1. `kora` (Meta-package: `korajs`)
            1.2.1.1. Re-exports core libraries
            1.2.1.2. Provides `createApp` factory
        1.2.2. `packages/*` (Core Libraries)
            1.2.2.1. `@korajs/core`
            1.2.2.2. `@korajs/store`
            1.2.2.3. `@korajs/merge`
            1.2.2.4. `@korajs/sync`
            1.2.2.5. `@korajs/auth`
            1.2.2.6. `@korajs/react`
            1.2.2.7. `@korajs/cli`
            1.2.2.8. `@korajs/devtools`
            1.2.2.9. `@korajs/server`
            1.2.2.10. `@korajs/tauri`
        1.2.3. `e2e`, `e2e/fixture-app` (End-to-End Testing)
        1.2.4. `docs` (Documentation Website)
    1.3. Key Technical Patterns
        1.3.1. Event-Driven Architecture (`KoraEventEmitter`)
        1.3.2. Optimistic UI / Local-First Writes
        1.3.3. Asynchronous Initialization (`app.ready` Promise)
        1.3.4. Strong TypeScript Inference
        1.3.5. DevTools Instrumentation

## 2. Core Building Blocks (`@korajs/core`)
    2.1. Schema Definition
        2.1.1. `defineSchema`, `t` (Type Builders)
        2.1.2. Collections, Fields, Indexes, Relations
        2.1.3. Constraints (for Merge Engine)
        2.1.4. Schema Versioning
    2.2. Operations
        2.2.1. Immutable Unit of Change (Insert, Update, Delete)
        2.2.2. `HLCTimestamp` (Hybrid Logical Clock)
            2.2.2.1. Causal Ordering
            1.2.2.2. Deterministic Tie-breaking
        2.2.3. `UUIDv7` (Time-ordered IDs)
        2.2.4. `VersionVector` (Tracks HLCs per node)
    2.3. `KoraEventEmitter` (Internal Communication)
    2.4. Core Types (`Operation`, `MergeStrategy`, `Constraint`, etc.)

## 3. Local Data Management (`@korajs/store`)
    3.1. `Store` Class
        3.1.1. Manages local database
        3.1.2. Applies Operations
        3.1.3. Provides CRUD methods
    3.2. `StorageAdapter` Abstraction
        3.2.1. `sqlite-wasm` (OPFS, Web Worker for performance)
        3.2.2. `indexeddb` (Browser fallback)
        3.2.3. `better-sqlite3` (Node.js)
        3.2.4. `detectAdapterType` (Auto-detection)
    3.3. Reactive Queries (Auto-updates UI)
    3.4. `yjs` Integration
        3.4.1. Used for `t.richtext()` fields
        3.4.2. Character-level CRDT merging
    3.5. Data Flow: Local Mutations -> `Store` -> `Operation` Generation -> `operation:created` Event

## 4. Conflict Resolution (`@korajs/merge`)
    4.1. `MergeEngine` Class
    4.2. Three-Tier Resolution Strategy
        4.2.1. Tier 1: Auto-Merge (Default per field type)
            4.2.1.1. LWW (Last-Write-Wins) for Scalars (string, number, boolean, enum, timestamp)
            4.2.1.2. Add-Wins Set for Arrays (`t.array()`)
            4.2.1.3. Yjs CRDT for Rich Text (`t.richtext()`)
        4.2.2. Tier 2: Constraints (Declarative Rules from Schema)
            4.2.2.1. `unique`
            4.2.2.2. `capacity`
            4.2.2.3. `referential`
            4.2.2.4. `onConflict` Strategies (`first-write-wins`, `priority-field`, `server-decides`, `custom`)
        4.2.3. Tier 3: Custom Resolvers (Developer-defined functions)
            4.2.3.1. For domain-specific logic (e.g., additive inventory)
            4.2.3.2. Receives `local`, `remote`, `base` values
    4.3. Determinism Guarantees (Commutativity, Idempotency, HLC Tie-breaking)
    4.4. `MergeTrace` (Debugging Conflict Decisions)

## 5. Data Synchronization (`@korajs/sync`)
    5.1. `SyncEngine` Class
    5.2. `WebSocketTransport` (Default Transport)
    5.3. Delta Sync
        5.3.1. Uses `VersionVector`s to identify missing operations
        5.3.2. Exchanges only necessary changes
    5.4. Causal Ordering (Operations sent in correct dependency order)
    5.5. Automatic Reconnection (`ReconnectionManager`, Exponential Backoff)
    5.6. `protobufjs` (Efficient Binary Wire Format)
    5.7. Authentication Integration
        5.7.1. Async `auth` function for tokens
        5.7.2. Server-Side Scoping (based on user permissions)
    5.8. Data Flow: `operation:created` (from Store) -> `SyncEngine` Queue -> Network -> `MergeAwareSyncStore` (in `kora`)

## 6. Application Orchestration (`kora` Meta-package)
    6.1. `createApp` Function (Main Entry Point for Developers)
        6.1.1. `KoraConfig` (Schema, Sync Options, Store Options)
        6.1.2. `app.ready` Promise (Asynchronous Initialization)
        6.1.3. Dynamic Collection Accessors (e.g., `app.todos.insert()`)
        6.1.4. `SyncControl` (`connect`, `disconnect`, `getStatus`)
        6.1.5. Resource Management (`app.close()`)
    6.2. `initializeAsync` (Internal Core Setup Logic)
        6.2.1. Resolves `StorageAdapter`
        6.2.2. Initializes `Store`
        6.2.3. Initializes `SyncEngine` (if configured)
    6.3. `MergeAwareSyncStore` (Crucial Integration Point)
        6.3.1. Internal to `createApp`
        6.3.2. Wraps `Store` and `MergeEngine`
        6.3.3. Acts as the `store` for `SyncEngine`
        6.3.4. Ensures all incoming sync operations are processed by `MergeEngine` before local application

## 7. Authentication (`@korajs/auth`)
    7.1. Client-Side (`AuthClient`)
        7.1.1. Sign-up, Sign-in, Session Management
        7.1.2. Passkeys (WebAuthn)
        7.1.3. Encrypted Token Storage (XSS protection)
    7.2. Server-Side (`@korajs/auth/server`)
        7.2.1. `BuiltInAuthRoutes` (HTTP handlers)
        7.2.2. `TokenManager` (JWTs, rotation, revocation)
        7.2.3. `UserStore`, `SessionManager`, `TotpManager` (MFA)
        7.2.4. `RbacEngine`, `OrgRoutes` (Organizations, Role-Based Access Control)
    7.3. Device Identity (ECDSA P-256 Key Pairs)
        7.3.1. Proof-of-possession
        7.3.2. Device registration and revocation
    7.4. Seamless Integration with Sync Server

## 8. Development & Contribution
    8.1. Testing (`vitest`, Property-Based Testing with `fast-check`)
    8.2. Linting & Formatting (`biome`)
    8.3. Type Checking (`tsc`)
    8.4. Build Process (`tsup`, `turbo`)
    8.5. Versioning & Releases (`changesets`)
    8.6. Documentation (Updating `docs/` and `content/`)
