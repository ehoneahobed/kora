# Kora.js Contributor Guide: Understanding the Codebase

This document aims to provide a deep technical understanding of the Kora.js codebase, going beyond the user-facing documentation. It's designed for developers who want to contribute to the framework, requiring a clear grasp of its architecture, core concepts, and inter-module interactions.

## 1. Overall Philosophy & Core Principles

Kora.js is an **offline-first application framework** built on principles of **eventual consistency**, **causal ordering**, and **deterministic conflict resolution**. Its primary goal is to abstract away the complexities of distributed data management, allowing developers to build highly resilient, collaborative, and responsive applications that function seamlessly regardless of network connectivity.

Key principles:
*   **Local-First:** All operations are applied locally first, providing an optimistic and immediate user experience.
*   **Operation-Based:** All data changes are represented as immutable, causally-ordered operations.
*   **Eventual Consistency:** Data converges across replicas over time, even with concurrent offline edits.
*   **Deterministic Merging:** Given the same set of operations, all replicas will arrive at the identical merged state.
*   **TypeScript-First:** Strong type inference and safety are paramount throughout the codebase.

## 2. Monorepo Structure (`pnpm-workspace.yaml` & `turbo.json`)

Kora.js is a monorepo managed with `pnpm` and `turbo`.

*   **`pnpm-workspace.yaml`**: Defines the packages within the monorepo.
    *   `packages/*`: Contains the core libraries that make up the Kora.js ecosystem (e.g., `auth`, `core`, `merge`, `store`, `sync`, `react`, `cli`, `devtools`, `server`, `tauri`).
    *   `kora`: The meta-package (`korajs`) that re-exports and orchestrates the core libraries into a single, cohesive API for end-users.
    *   `e2e`, `e2e/fixture-app`: End-to-end testing infrastructure.
    *   `docs`: The documentation website.

*   **`turbo.json`**: Configures the `turbo` task runner for efficient execution of scripts across packages. It defines task dependencies, caching strategies, and outputs for `build`, `test`, `lint`, `typecheck`, `dev`, and `clean` commands. Understanding `turbo.json` is crucial for running development tasks efficiently.

## 3. Core Concepts & Data Flow

This section details the main modules and how data flows through them.

### 3.1. `@korajs/core`: The Foundation

This package provides the fundamental building blocks, data structures, and algorithms that underpin the entire framework. It defines the "language" of Kora.js data and changes.

*   **`SchemaInput`, `SchemaDefinition`**: The blueprint for your application's data model. Defined using `defineSchema` and `t` (type builders). Includes collections, fields, indexes, constraints, and relations.
*   **`Operation`**: The atomic unit of change in Kora.js. An immutable record describing a data modification (insert, update, delete) on a specific collection and record.
    *   **`HLCTimestamp` (Hybrid Logical Clock)**: A timestamp that provides a total ordering of events across distributed systems without requiring perfectly synchronized clocks. Each operation is timestamped with an HLC.
    *   **`UUIDv7`**: Time-ordered UUIDs used for unique record identification and efficient indexing.
    *   **`VersionVector`**: A data structure that tracks the highest HLC timestamp seen from each node (device/server). Used by the sync engine to determine which operations are missing from a replica.
*   **`KoraEventEmitter`**: A simple event emitter used for internal communication between modules (e.g., `operation:created`, `sync:connected`).
*   **`Constraint`**: Declarative rules defined in the schema to enforce data integrity and guide conflict resolution.
*   **`MergeStrategy`**: Defines how conflicts are resolved for specific fields or constraints.

### 3.2. `@korajs/store`: Local Persistence & Reactive Queries

The local data store, responsible for persisting data on the client and providing a reactive query interface.

*   **`StorageAdapter`**: An abstraction layer for different local storage backends.
    *   **`sqlite-wasm`**: Uses SQLite compiled to WebAssembly, often leveraging the Origin Private File System (OPFS) for high-performance, durable storage in browsers. Operations are typically offloaded to a Web Worker.
    *   **`indexeddb`**: A fallback adapter using the browser's native IndexedDB API.
    *   **`better-sqlite3`**: For Node.js environments, providing native SQLite persistence.
*   **`Store` Class**: Manages the local database, applies operations, and provides CRUD methods for collections.
    *   **Reactive Queries**: Queries return results immediately and automatically update when underlying data changes, enabling responsive UIs.
    *   **`yjs` Integration**: For `t.richtext()` fields, `@korajs/store` uses Yjs (a CRDT library) to manage character-level collaborative editing. This means the raw Yjs document state is stored, and Kora.js operations are generated to reflect changes to this state.
*   **Data Flow:**
    1.  Local mutations (e.g., `app.todos.insert()`) are applied optimistically to the `Store`.
    2.  The `Store` generates an `Operation` for the change.
    3.  The `Store` emits an `operation:created` event.

### 3.3. `@korajs/merge`: The Conflict Resolution Engine

This package houses the sophisticated logic for resolving concurrent data modifications.

*   **`MergeEngine` Class**: The core component for conflict resolution.
*   **Three-Tier Resolution Strategy**:
    1.  **Tier 1 (Auto-Merge):** Default strategies based on field type:
        *   **Last-Write-Wins (LWW):** For scalar fields (`string`, `number`, `boolean`, `enum`, `timestamp`). Uses HLC timestamps for deterministic tie-breaking.
        *   **Add-Wins Set:** For `t.array()` fields, taking the union of elements.
        *   **Yjs CRDT:** For `t.richtext()` fields, providing character-level merging.
    2.  **Tier 2 (Constraints):** Declarative rules defined in the schema (`unique`, `capacity`, `referential`). If a constraint is violated by an auto-merged state, a specified `onConflict` strategy (e.g., `first-write-wins`, `priority-field`, `server-decides`, `custom`) is applied.
    3.  **Tier 3 (Custom Resolvers):** Developer-defined functions for highly specific, domain-driven merge logic. These functions receive `local`, `remote`, and `base` values to compute the resolved state.
*   **Determinism**: The merge engine guarantees that, given the same set of operations, every device will produce the identical merged state, regardless of operation arrival order. This is achieved through commutativity, idempotency, and deterministic tie-breaking using HLCs and node IDs.
*   **`MergeTrace`**: A detailed record of how each conflict was resolved, invaluable for debugging.

### 3.4. `@korajs/sync`: Data Synchronization Protocol

Manages the exchange of operations between the local store and remote replicas (typically a Kora.js server).

*   **`SyncEngine` Class**: Orchestrates the synchronization process.
*   **`WebSocketTransport`**: The primary transport mechanism, enabling low-latency, bidirectional streaming of operations.
*   **Delta Sync**: Uses `VersionVector`s to efficiently determine and exchange only the operations missing from each replica.
*   **Causal Ordering**: Ensures operations are applied in the correct logical order, respecting dependencies, even if they arrive out of sequence.
*   **Automatic Reconnection**: Implements exponential backoff to gracefully handle network interruptions and resume synchronization.
*   **`protobufjs`**: Used for efficient binary serialization of operations over the wire, reducing payload size.
*   **Authentication**: Supports an async `auth` function to provide tokens for WebSocket handshake, integrating with `@korajs/auth` for secure sync.
*   **Server-Side Scoping**: Allows the server to filter operations based on user permissions, ensuring clients only receive authorized data.
*   **Data Flow:**
    1.  `SyncEngine` receives `operation:created` events from the local `Store` (via `createApp`) and queues them for sending.
    2.  It sends local operations to the server and receives remote operations from the server.
    3.  Incoming remote operations are passed to the `MergeAwareSyncStore` for conflict resolution before being applied to the local `Store`.

### 3.5. `kora` (Meta-package): The Application Entry Point

This package (`korajs`) is what end-users import. It re-exports core components and provides the `createApp` factory.

*   **`createApp` Function**: (Detailed in previous analysis) The central orchestrator.
    *   Initializes `Store`, `MergeEngine`, `SyncEngine`, `EventEmitter`.
    *   Manages the `app.ready` promise for asynchronous setup.
    *   Dynamically creates collection accessors (e.g., `app.todos`).
    *   **`MergeAwareSyncStore`**: A critical internal component within `createApp` that wraps the `Store` and `MergeEngine`. It acts as the `store` parameter for the `SyncEngine`, ensuring that all incoming operations from the network are first processed by the `MergeEngine` before being committed to the local `Store`. This is the direct integration point for conflict resolution during sync.
    *   Handles reconnection logic (`ReconnectionManager`, `ConnectionMonitor`).
    *   Integrates DevTools instrumentation.

### 3.6. `@korajs/auth`: Secure Authentication for Offline-First

A comprehensive client-server authentication system designed for Kora.js applications.

*   **Client-Side (`@korajs/auth`)**: `AuthClient` for sign-up, sign-in, session management, passkeys, encrypted token storage.
*   **Server-Side (`@korajs/auth/server`)**: `BuiltInAuthRoutes`, `TokenManager`, `UserStore`, `SessionManager`, `TotpManager`, `RbacEngine`, `OrgRoutes`.
*   **Device Identity**: Uses ECDSA P-256 key pairs for proof-of-possession, enabling secure device registration and revocation.
*   **Integration with Sync**: Provides `toSyncAuthProvider()` to bridge authentication with the Kora.js sync server, allowing for authenticated and mixed (anonymous + authenticated) sync.

## 4. Key Technical Patterns

### 4.1. Event-Driven Architecture

Kora.js heavily relies on an internal event system (`KoraEventEmitter`). Modules emit events (e.g., `operation:created`, `sync:connected`, `merge:conflict`), and other modules or the `createApp` factory listen to these events to trigger subsequent actions. This promotes loose coupling and modularity.

### 4.2. Optimistic UI & Local-First Writes

All data mutations are applied to the local `Store` immediately. This means the UI updates instantly, providing a highly responsive experience. The actual synchronization to the server happens in the background. If the network is unavailable, operations are queued and sent later.

### 4.3. Asynchronous Initialization (`app.ready`)

The `createApp` function returns an `app` object with a `ready` promise. This allows the application to start quickly while the underlying local database and sync engine are initialized asynchronously. Developers `await app.ready` before performing data operations to ensure the store is fully set up.

### 4.4. Strong TypeScript Inference

The entire framework is built with TypeScript, leveraging advanced type inference. Defining your schema with `defineSchema` and `t` automatically provides full type safety and autocomplete for all collection operations, significantly enhancing developer experience and reducing bugs.

### 4.5. DevTools Instrumentation

Kora.js includes built-in instrumentation (`@korajs/devtools`) that emits internal events to a DevTools bridge. This allows for real-time inspection of sync status, operations, merge traces, and other internal states, which is invaluable for debugging and understanding complex distributed behaviors.

## 5. Contribution Guidelines (High-Level)

*   **Code Style:** Adhere to the existing code style enforced by `biome check .`. Use `pnpm lint:fix` to automatically format and fix linting issues.
*   **Testing:** All new features and bug fixes should be accompanied by unit and/or integration tests using `vitest`. Run tests with `pnpm test`. Property-based testing (`fast-check`) is used for critical merge logic.
*   **Type Safety:** Ensure all code is type-safe. Run `pnpm typecheck` regularly.
*   **Build Process:** The project uses `tsup` for TypeScript compilation and bundling, orchestrated by `turbo`.
*   **Versioning & Releases:** Changes are managed with `changesets`. When making changes that affect users, create a changeset (`pnpm changeset`) to describe the change, which will be used for automated versioning and changelog generation.
*   **Documentation:** Update relevant documentation files in the `docs/` directory for any new features, changes, or clarifications.

---

This guide provides a comprehensive overview of the Kora.js codebase. As you delve into specific files and modules, refer back to this document to understand how each piece fits into the larger architecture. Good luck, and happy contributing!
