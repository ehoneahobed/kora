## Default Permission

Default permissions for the Kora SQLite storage plugin. Grants access to all database operations.

#### This default permission set includes the following:

- `allow-open`
- `allow-close`
- `allow-execute`
- `allow-query`
- `allow-migrate`

## Permission Table

<table>
<tr>
<th>Identifier</th>
<th>Description</th>
</tr>


<tr>
<td>

`kora-sqlite:allow-close`

</td>
<td>

Enables the close command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:deny-close`

</td>
<td>

Denies the close command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:allow-execute`

</td>
<td>

Enables the execute command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:deny-execute`

</td>
<td>

Denies the execute command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:allow-migrate`

</td>
<td>

Enables the migrate command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:deny-migrate`

</td>
<td>

Denies the migrate command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:allow-open`

</td>
<td>

Enables the open command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:deny-open`

</td>
<td>

Denies the open command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:allow-query`

</td>
<td>

Enables the query command without any pre-configured scope.

</td>
</tr>

<tr>
<td>

`kora-sqlite:deny-query`

</td>
<td>

Denies the query command without any pre-configured scope.

</td>
</tr>
</table>
